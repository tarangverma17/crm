<?php
session_start();
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
$con = mysqli_connect("localhost", "root", "", "crm");

if (mysqli_connect_errno()) {
    echo "Connection failed: " . mysqli_connect_error();
    exit();
}

if (!isset($_SESSION['login'])) {
    echo "Please log in first.";
    exit();
}

$email = $_SESSION['login'];

if (isset($_POST['submit'])) {
    $count_my_page = "hitcounter.txt";
    if (!file_exists($count_my_page)) {
        echo "File not found.";
        exit();
    }

    $hits = file($count_my_page);
    if (!is_numeric($hits[0])) {
        echo "Invalid file contents.";
        exit();
    }
    $hits[0]++;
    $fp = fopen($count_my_page, "w");
    fputs($fp, "$hits[0]");
    fclose($fp);
    $tid = $hits[0];

    // Get form inputs
    $enduser_contact_name = $_POST['enduser_contact_name'];
    $enduser_contact_email = $_POST['enduser_contact_email'];
    $enduser_contact_phone = $_POST['enduser_contact_phone'];
    $alt_contact_name = $_POST['alt_contact_name'];
    $alt_contact_phone = $_POST['alt_contact_phone'];
    $alt_contact_email = $_POST['alt_contact_email'];
    $subject = $_POST['subject'];
    $tt = $_POST['tasktype'];
    $priority = $_POST['priority'];
    $ticket = $_POST['description'];
    $internal_notes = $_POST['internal_notes'];
    $st = "Open";
    $pdate = date('Y-m-d');

    // Prepare SQL statement
    $stmt = mysqli_prepare($con, "INSERT INTO ticket(ticket_id, email_id, enduser_contact_name, enduser_contact_email, enduser_contact_phone, alt_contact_name, alt_contact_phone, alt_contact_email, subject, task_type, priority, ticket, status, posting_date, internal_notes)
                                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "issssssssssssss", $tid, $email, $enduser_contact_name, $enduser_contact_email, $enduser_contact_phone, $alt_contact_name, $alt_contact_phone, $alt_contact_email, $subject, $tt, $priority, $ticket, $st, $pdate, $internal_notes);

    $a = mysqli_stmt_execute($stmt);

    if ($a) {
        echo "<script>alert('Ticket Generated');</script>";
    } else {
        echo "<script>alert('Error generating ticket. Please try again.');</script>";
        echo "Error: " . mysqli_error($con);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>CRM | Create Ticket</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
</head>
<body class="">
<?php include("header.php"); ?>
<div class="page-container row-fluid">
    <?php include("leftbar.php"); ?>
    <div class="clearfix"></div>
  </div>
  </div>
  <a href="#" class="scrollup">Scroll</a>
  <div class="footer-widget">
    <div class="progress transparent progress-small no-radius no-margin">
        <div data-percentage="79%" class="progress-bar progress-bar-success animate-progress-bar"></div>
    </div>
    <div class="pull-right"></div>
  </div>

<!-- BEGIN PAGE CONTAINER-->
<div class="page-content">
    <div class="clearfix"></div>

    <div class="content">
        <div class="page-title">
<h3 class="bold-heading">Create Ticket</h3>

        </div>

        <div class="row">
            <div class="col-md-12">
                <form class="form-horizontal" name="form1" method="post" action="" onsubmit="return valid();">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <p class="text-center text-danger"><?= $_SESSION['msg1']; ?><?= $_SESSION['msg1'] = ""; ?></p>

                           <!-- Enduser Details -->
                            <fieldset class="border p-4 mb-4">
                                <legend class="w-auto px-2">Enduser Details*</legend>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <div class="form-group">
                                            <label for="enduser_contact_name">Contact Name*</label>
                                            <input type="text" id="enduser_contact_name" name="enduser_contact_name" class="form-control form-control-lg" required placeholder="Enter Contact Name">
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-group">
                                            <label for="enduser_contact_email">Contact Email*</label>
                                            <input type="email" id="enduser_contact_email" name="enduser_contact_email" class="form-control form-control-lg" required placeholder="Enter Contact Email">
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-group">
                                            <label for="enduser_contact_phone">Contact Phone*</label>
                                            <input type="text" id="enduser_contact_phone" name="enduser_contact_phone" class="form-control form-control-lg" required placeholder="Enter Contact Phone">
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Alternate Contact -->
                            <fieldset class="border p-4 mb-4">
                                <legend class="w-auto px-2">Alternate Contact*</legend>
                                <div class="row">
                                    <div class="col-md-4 mb-3">
                                        <div class="form-group">
                                            <label for="alt_contact_name">Alt Contact Name</label>
                                            <input type="text" id="alt_contact_name" name="alt_contact_name" class="form-control form-control-lg" placeholder="Enter Contact Name">
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-group">
                                            <label for="alt_contact_phone">Alt Contact Phone</label>
                                            <input type="text" id="alt_contact_phone" name="alt_contact_phone" class="form-control form-control-lg" placeholder="Enter Contact Phone">
                                        </div>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <div class="form-group">
                                            <label for="alt_contact_email">Alt Contact Email</label>
                                            <input type="email" id="alt_contact_email" name="alt_contact_email" class="form-control form-control-lg" placeholder="Enter Contact Email">
                                        </div>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Subject -->
                            <fieldset class="border p-4 mb-4">
                                <legend class="w-auto px-2">Subject*</legend>
                                <div class="row">
                                    <div class="col-md-12 mb-4">
                                        <input type="text" id="subject" name="subject" class="form-control form-control-lg" required placeholder="Enter Subject">
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Task Type -->
                            <fieldset class="border p-4 mb-4">
                                <legend class="w-auto px-2">Task Type*</legend>
                                <div class="row">
                                    <div class="col-md-12 mb-4">
                                        <select name="tasktype" id="tasktype" class="form-control form-control-lg" required>
                                            <option value="" disabled selected>Select your Task Type</option>
                                            <option value="billing">Billing</option>
                                            <option value="ot1">Option 1</option>
                                            <option value="ot2">Option 2</option>
                                            <option value="ot3">Option 3</option>
                                        </select>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Priority -->
                            <fieldset class="border p-4 mb-4">
                                <legend class="w-auto px-2">Priority*</legend>
                                <div class="row">
                                    <div class="col-md-12 mb-4">
                                        <select name="priority" id="priority" class="form-control form-control-lg" required>
                                            <option value="" disabled selected>Choose your Priority</option>
                                            <option value="important">Important</option>
                                            <option value="urgent">Urgent (Functional Problem)</option>
                                            <option value="non-urgent">Non-Urgent</option>
                                            <option value="question">Question</option>
                                        </select>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Problem Description -->
                            <fieldset class="border p-4 mb-4">
                                <legend class="w-auto px-2">Problem Description*</legend>
                                <div class="row">
                                    <div class="col-md-12 mb-4">
                                        <textarea class="form-control form-control-lg" name="description" rows="4" required placeholder="Describe the problem"></textarea>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Internal Note -->
                            <fieldset class="border p-4 mb-4">
                                <legend class="w-auto px-2">Internal Note*</legend>
                                <div class="row">
                                    <div class="col-md-12 mb-4">
                                        <textarea class="form-control form-control-lg" name="internal_notes" rows="4" required placeholder="Add internal notes"></textarea>
                                    </div>
                                </div>
                            </fieldset>

                            <!-- Form Actions -->
                            <div class="panel-footer text-right">
                                <button type="reset" class="btn btn-secondary btn-lg">Clear Form</button>
                                <button type="submit" name="submit" class="btn btn-primary btn-lg">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>


<script type="text/javascript">
    function valid() {
        var enduser_contact_name = document.getElementById('enduser_contact_name').value;
        var enduser_contact_email = document.getElementById('enduser_contact_email').value;
        var enduser_contact_phone = document.getElementById('enduser_contact_phone').value;
        var subject = document.getElementById('subject').value;
        var tasktype = document.getElementById('tasktype').value;
        var priority = document.getElementById('priority').value;
        var description = document.getElementById('description').value;
        var internal_notes = document.getElementById('internal_notes').value;

        if (!enduser_contact_name || !enduser_contact_email || !enduser_contact_phone || !subject || !tasktype || !priority || !description || !internal_notes) {
            alert("All fields are required.");
            return false;
        }
        return true;
    }
</script>

<script src="assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/plugins/breakpoints.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="assets/js/core.js" type="text/javascript"></script>
<script src="assets/js/chat.js" type="text/javascript"></script>
<script src="assets/js/demo.js" type="text/javascript"></script>
</body>
</html>


<style>

    .page-title {
        text-align: left;
        font-weight: bold;
        font-size: 24px; /* Reduced font size */
        margin-top: 30px;
    }

    .form-group label {
        font-weight: bold;
        margin-bottom: 10px;
        font-size: 14px; /* Reduced font size */
    }

    .form-control {
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }


    .form-control input,
    .form-control select,
    .form-control textarea,{
        font-size: 14px; /* Reduced font size */
        padding: 10px;
        margin-bottom: 15px;
    }


    #subject {
        border-radius: 15px;
        font-size: 16px; /* Reduced font size */
        padding: 20px;
        margin-bottom: 20px;
    }

    #priority {
        border-radius: 8px;
        font-size: 16px; /* Reduced font size */
        padding: 3px;
        margin-bottom: 20px;
    }

    #tasktype {
        border-radius: 8px;
        font-size: 16px; /* Reduced font size */
        padding: 3px;
        margin-bottom: 20px;
    }

    #internal_note {
        border-radius: 20px;
        font-size: 16px; /* Reduced font size */
        padding: 20px;
        margin-bottom: 20px;
    }

    #description {
        border-radius: 8px;
        font-size: 16px; /* Reduced font size */
        padding: 12px;
        margin-bottom: 20px;

    }

    .form-control-lg {
        height: 50px;
    }

    .panel-body {
        background-color: #f9f9f9;
        padding: 40px;
    }

    .panel-footer {
        background-color: #fff;
        border-top: 1px solid #ddd;
        padding: 20px;
        text-align: right;
    }

    .btn-primary, .btn-secondary {
        padding: 10px 16px; /* Slightly smaller padding */
        font-size: 14px; /* Reduced font size */
        border-radius: 5px;
    }

    .btn-primary {
        background-color: #007bff;
        color: white;
    }

    .btn-secondary {
        background-color: #6c757d;
        color: white;
    }

    .legend {
        font-size: 16px; /* Reduced font size */
        font-weight: bold;
    }

    .fieldset {
        border: 1px solid #ddd;
        padding: 20px;
        border-radius: 8px;
    }

    .panel-body {
        background-color: #f9f9f9;
        padding: 30px;
        max-width: 500%;
        width: 150%;
        margin: 0 auto;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .panel-body.large {
        width: 300%;
        max-width: 1200px;
        height: auto;
    }
.bold-heading {
    font-weight: bold;  /* Makes the text bold */
}



    @media (max-width: 768px) {
        .panel-body {
            padding: 20px;
        }
        .panel-body.large {
            width: 100%;
            height: auto;
        }
    }

</style>



