<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "crm";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get ticket number from URL and sanitize the input
$ticket_id = isset($_GET['ticket_id']) ? (int)$_GET['ticket_id'] : 0; // Cast to integer to prevent SQL injection

if ($ticket_id > 0) {
    // SQL query to fetch data based on ticket_id (using prepared statement)
    $sql = "SELECT * FROM ticket WHERE ticket_id = ?";

    // Prepare and bind the statement
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $ticket_id); // "i" stands for integer
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $ticket = $result->fetch_assoc();
        } else {
            echo "No ticket found.";
            exit;
        }
        $stmt->close();
    } else {
        echo "SQL Error: " . $conn->error;
        exit;
    }
}

// Handle form submission for updating remarks
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $internal_notes = $_POST['internal_notes'];
    // Sanitize the input if needed
    $ticket_id = $_POST['ticket_id'];

    // Update the ticket record in the database
    $update_sql = "UPDATE ticket SET internal_notes = ? WHERE ticket_id = ?";
    if ($stmt = $conn->prepare($update_sql)) {
        $stmt->bind_param("si", $internal_notes, $ticket_id);
        if ($stmt->execute()) {
            echo "<script>alert('Ticket updated successfully!');</script>";
        } else {
            echo "<script>alert('Error updating ticket.');</script>";
        }
        $stmt->close();
    } else {
        echo "SQL Error: " . $conn->error;
    }
}

// Close connection after form submission
$conn->close();
?>


<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>User | Ticket Support</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
</head>
<body class="">
<?php include("header.php");?>
<div class="page-container row">
  <?php include("leftbar.php");?>
  <div class="clearfix"></div>
  </div>
  </div>

<style>
    /* General Body Styling */
    body {
        font-family: Arial, sans-serif;
        background-color: #f7f7f7;
        padding-top: 50px;
        color: #333;
    }

    /* Container Styling */
    .container {
        max-width: 800px;
        padding-top: 30px;

    }

    /* Heading Styling */
    h3 {
        color: #007bff;
        text-align: center;
        margin-top: 40px;
        font-weight: 800;
        margin-bottom: 5px;
    }

/*    /* Form Group Styling */
    .form-group label {
        font-weight: bold;
        color: #333;
    }

    .form-control {
        border-radius: 5px;
        box-shadow: none;
        border: 1px solid #ced4da;
        font-size: 14px;
        padding: 10px;
    }

    .form-control:focus {
        border-color: #007bff;
        box-shadow: 0 0 8px rgba(0, 123, 255, 0.25);
    }

    /* Button Styling */
    .btn {
        border-radius: 5px;
        padding: 10px 20px;
        font-size: 16px;
        width: 100%;
        cursor: pointer;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .btn-warning {
        background-color: #ffc107;
        border-color: #ffc107;
        width: auto;
        display: inline-block;
    }

    .btn-warning:hover {
        background-color: #e0a800;
        border-color: #e0a800;
    }

    /* Back Button Styling */
    .btn-warning {
        margin-top: 20px;
    }

    /* Alert Styling */
    .alert {
        text-align: center;
    }

    /* Styling for Read-Only Inputs */
    .form-control[readonly] {
        background-color: #e9ecef;
        color: #6c757d;
    }

    /* Responsiveness: Smaller Devices */
    @media (max-width: 767px) {
        .container {
            padding: 15px;
        }

        .btn {
            font-size: 14px;
            padding: 8px 15px;
        }
    }
</style>

</head>
<body>

<div class="container mt-5">


<h3>Ticket Details</h3>
        <!-- Back Button on the right -->
        <div style="text-align: right; margin-bottom: 15px;">
            <a href="view-tickets.php" class="btn btn-warning mt-3">Back to Manage Tickets</a>
        </div>

<?php if (isset($ticket)): ?>
    <form method="POST" action="">
        <input type="hidden" name="ticket_id" value="<?php echo $ticket['ticket_id']; ?>">






            <div class="form-group">
                <label for="ticket_id">Ticket Id No# <?php echo $ticket_id; ?></label>
                <input type="text" class="form-control" id="ticket_id" value="<?php echo $ticket['ticket_id']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="enduser_contact_name">Contact Name</label>
                <input type="text" class="form-control" id="enduser_contact_name" value="<?php echo $ticket['enduser_contact_name']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="enduser_contact_email">Email</label>
                <input type="email" class="form-control" id="enduser_contact_email" value="<?php echo $ticket['enduser_contact_email']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="enduser_contact_phone">Phone</label>
                <input type="text" class="form-control" id="enduser_contact_phone" value="<?php echo $ticket['enduser_contact_phone']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="subject">Subject</label>
                <input type="text" class="form-control" id="subject" value="<?php echo $ticket['subject']; ?>" readonly>
            </div>

            <div class="form-group">
                <label for="ticket_description">Description</label>
                <textarea class="form-control" id="ticket_description" rows="3" readonly><?php echo nl2br($ticket['ticket']); ?></textarea>
            </div>

            <div class="form-group">
                <label for="priority">Priority</label>
                <input type="text" class="form-control" id="priority" value="<?php echo $ticket['priority']; ?>" readonly>
            </div>



            <div class="form-group">
                <label for="internal_note">Internal Note</label>
                <textarea name="internal_notes" class="form-control" id="internal_notes" rows="4"><?php echo $ticket['internal_notes']; ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Update Ticket</button>
        </form>
            <!-- Back Button -->
<!-- <a href="../admin/manage-tickets.php" class="btn btn-warning mt-3">Back to Manage Tickets</a> -->

</div>
</body>
</body>
</html>

    <?php else: ?>
        <p>No ticket found.</p>
    <?php endif; ?>
<!-- JS and Bootstrap scripts -->
<script src="assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/core.js" type="text/javascript"></script>
<script src="assets/js/chat.js" type="text/javascript"></script>
</body>
</html>
</body>
</html>