  <!-- Footer -->
  <footer class="py-5 bg-black">
    <div class="container">
      <p class="m-0 text-center text-white small">Copyright &copy; CRM TPM GURU 2025</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>

<head>
  <style>
    /* Footer Styling */
    footer {
        background-color: #000;  /* Black background */
        color: #fff;             /* White text color */
        padding: 20px 0;         /* Vertical padding */
        text-align: left;        /* Align text to the left */
        position: relative;      /* To allow it to work with absolute positioning if necessary */
        bottom: 0;               /* Stick the footer to the bottom of the page */
        width: 100%;             /* Full width */
    }

    footer p {
        margin: 0;               /* Remove margin from the paragraph */
        font-size: 14px;         /* Smaller font size for the footer text */
        text-transform: uppercase; /* Optional: to make text uppercase */
    }

    @media (max-width: 768px) {
        footer p {
            font-size: 12px;  /* Smaller font size on mobile devices */
        }
    }
  </style>
</head>
