<?php
session_start();
// error_reporting(0);
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("dbconnection.php");

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];

    // print_r($_POST);
    // Check if email is already registered
    $query = mysqli_query($con, "SELECT email FROM user WHERE email='$email'");
    echo "Query: SELECT email FROM user WHERE email='$email'";
    if (!$query) {
    die("Query failed: " . mysqli_error($con));
}

    $num = mysqli_num_rows($query);

    // if ($num > 0) {
    //     echo "<script>alert('Email-id already registered with us. Please try with a different email id.');</script>";
    //     echo "<script>window.location.href='registration.php';</script>";
    // } else {
        // Insert new user record
        $insert_query = mysqli_query($con, "INSERT INTO user(name, email, password, phone, gender) VALUES('$name', '$email', '$password', '$phone', '$gender')");

        if ($insert_query) {
            echo "<script>alert('Successfully registered with us. Now you can login');</script>";
            echo "<script>window.location.href='login.php';</script>";
        } else {
            echo "<script>alert('There was an error. Please try again later.');</script>";
        }
    // }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>CRM | Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>

    <script type="text/javascript">
        // Check password match
        function checkpass() {
            // Password match validation
            if (document.signup.password.value !== document.signup.cpassword.value) {
                alert('New Password and Re-Password fields do not match');
                document.signup.cpassword.focus();
                return false;
            }
            return true;
        }
    </script>
</head>
<body class="error-body no-top">
    <div class="container">
        <div class="row login-container column-seperation">
            <div class="col-md-5 col-md-offset-1">
                <h2>Sign in to CRM</h2>
                <p><a href="login.php">Sign in Now!</a></p>
            </div>
            <div class="col-md-5">
                <form id="signup" name="signup" class="login-form" onsubmit="return checkpass();" method="post">
                    <div class="row">
                        <div class="form-group col-md-10">
                            <label class="form-label">Name</label>
                            <div class="controls">
                                <input type="text" name="name" id="name" class="form-control" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-10">
                            <label class="form-label">Email id</label>
                            <div class="controls">
                                <input type="email" name="email" id="email" class="form-control" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-10">
                            <label class="form-label">Password</label>
                            <div class="controls">
                                <input type="password" name="password" id="password" class="form-control" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-10">
                            <label class="form-label">Re-Password</label>
                            <div class="controls">
                                <input type="password" name="cpassword" id="cpassword" class="form-control" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-10">
                            <label class="form-label">Contact no.</label>
                            <div class="controls">
                                <input type="text" name="phone" id="phone" class="form-control" pattern="[0-9]{10}" title="10 numeric characters only" required="true">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-10">
                            <label class="form-label">Gender</label>
                            <div class="controls">
                                <input type="radio" value="m" name="gender" checked> Male
                                <input type="radio" value="f" name="gender"> Female
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-10">
                            <input class="btn btn-primary btn-cons pull-right" name="submit" value="Submit" type="submit" />
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>
