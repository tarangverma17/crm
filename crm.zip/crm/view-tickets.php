<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();

// Get the total count of tickets for the logged-in user
$result = mysqli_query($con, "SELECT COUNT(*) AS total_tickets FROM ticket WHERE email_id='" . $_SESSION['login'] . "'");
$row = mysqli_fetch_assoc($result);
$total_tickets = $row['total_tickets'];
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>User | Ticket Support</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />

<link href="assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
</head>
<body class="">
<?php include("header.php");?>
<div class="page-container row">
  <?php include("leftbar.php");?>
  <div class="clearfix"></div>
  </div>
  </div>
  <div class="page-content">
    <div class="clearfix"></div>
    <div class="content">
      <ul class="breadcrumb">
        <li>
          <p>Home</p>
        </li>
        <li><a href="#" class="active">View Ticket</a></li>
      </ul>

      <div class="page-title"> <i class="icon-custom-left"></i>
        <h3>Ticket Support</h3>
      </div>

   <!--   <div class="clearfix"></div>
      <h4> <span class="semi-bold">Tickets</span></h4>
      <br>  -->

<!-- Display the total count of tickets in a card -->
<!-- Display the total count of tickets, open tickets, and closed tickets in separate cards -->
<div class="row">
  <!-- Total Tickets Card -->
  <div class="col-md-4">
    <div class="card card-inverse card-info">
      <div class="card-header">
        <h4 class="card-title text-center" style="font-size: 14px; font-weight: bold; color: #fff;">TOTAL TICKETS</h4>
      </div>
      <div class="card-body text-center" style="font-size: 16px; font-weight: bold; color: #fff;">
        <!-- <i class="fa fa-ticket" style="font-size: 30px; margin-bottom: 10px;"></i><br> -->
        <span><?php echo $total_tickets; ?></span>
      </div>
    </div>
  </div>

  <!-- Open Tickets Card -->
  <div class="col-md-4">
    <div class="card card-inverse card-primary">
      <div class="card-header">
        <h4 class="card-title text-center" style="font-size: 14px; font-weight: bold; color: #fff;">OPEN TICKETS</h4>
      </div>
      <div class="card-body text-center" style="font-size: 16px; font-weight: bold; color: #fff;">
        <!-- <i class="fa fa-folder-open" style="font-size: 30px; margin-bottom: 10px;"></i><br> -->
        <?php
        // Query to count open tickets
        $open_tickets_query = mysqli_query($con, "SELECT COUNT(*) AS open_tickets FROM ticket WHERE email_id='" . $_SESSION['login'] . "' AND status='open'");
        $open_tickets_result = mysqli_fetch_assoc($open_tickets_query);
        $open_tickets = $open_tickets_result['open_tickets'];
        ?>
        <span><?php echo $open_tickets; ?></span>
      </div>
    </div>
  </div>

  <!-- Closed Tickets Card -->
  <div class="col-md-4">
    <div class="card card-inverse card-success">
      <div class="card-header">
        <h4 class="card-title text-center" style="font-size: 14px; font-weight: bold; color: #fff;">CLOSED TICKETS</h4>
      </div>
      <div class="card-body text-center" style="font-size: 16px; font-weight: bold; color: #fff;">
        <!-- <i class="fa fa-folder" style="font-size: 30px; margin-bottom: 10px;"></i><br> -->
        <?php
        // Query to count closed tickets
        $closed_tickets_query = mysqli_query($con, "SELECT COUNT(*) AS closed_tickets FROM ticket WHERE email_id='" . $_SESSION['login'] . "' AND status='closed'");
        $closed_tickets_result = mysqli_fetch_assoc($closed_tickets_query);
        $closed_tickets = $closed_tickets_result['closed_tickets'];
        ?>
        <span><?php echo $closed_tickets; ?></span>
      </div>
    </div>
  </div>
</div>

<br></br>

<?php
$rt = mysqli_query($con, "SELECT * FROM ticket WHERE email_id='" . $_SESSION['login'] . "' ORDER BY id DESC");
$num = mysqli_num_rows($rt);
if($num > 0) {
    while($row = mysqli_fetch_array($rt)) {
?>
      <div class="row">
        <div class="col-md-12">
          <div class="grid simple no-border">
            <div class="grid-title no-border descriptive clickable">
              <h4 class="semi-bold"><?php echo $row['enduser_contact_name'];?></h4>
              <p><span class="text-success bold">Ticket #<?php echo $row['ticket_id'];?></span> - Created on <?php echo $row['posting_date'];?>
              <br></br>
<strong style="color: orange;">Status - </strong><span class="label <?php echo ($row['status'] == 'closed') ? 'label-important' : 'label-warning'; ?>" style="font-weight: bold;">
  <?php echo $row['status']; ?>
</span>

              </span>
              <div class="actions">
<button class="btn btn-blue" type="button" data-toggle="modal" data-target="#viewTicketModal<?php echo $row['ticket_id'];?>">
  <i class="fa fa-eye"></i> View
</button>
<button class="btn btn-warning view-button" type="button" onclick="window.location.href='user_view_ticket.php?ticket_id=<?php echo $row['ticket_id']; ?>'">
    <i class="fa fa-pencil"></i><strong style="color: white;">Edit</strong>
</button>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Modal Structure to view ticket details -->
      <div class="modal fade" id="viewTicketModal<?php echo $row['ticket_id'];?>" tabindex="-1" role="dialog" aria-labelledby="viewTicketModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
              <h5 class="modal-title" id="viewTicketModalLabel">Ticket Details</h5>
            </div>
            <div class="modal-body">
              <!-- Ticket Details -->
<div style="text-align: left;">
  <p><strong style="color: red;">Ticket id: </strong><span style="color: red;"><?php echo $row['ticket_id']; ?></span></p>
</div>
                              <strong style="color: green;">Status - </strong><span class="label <?php echo ($row['status'] == 'closed') ? 'label-important' : 'label-warning'; ?>" style="font-weight: bold;">
  <?php echo $row['status']; ?>
</span>
<br></br>

              <p><strong>Contact Name: </strong><?php echo $row['enduser_contact_name']; ?></p>
              <p><strong>Email: </strong><?php echo $row['enduser_contact_email']; ?></p>
              <p><strong>Phone: </strong><?php echo $row['enduser_contact_phone']; ?></p>
              <p><strong>Subject: </strong><?php echo $row['subject']; ?></p>
              <p><strong>Priority: </strong><?php echo $row['priority']; ?></p>
              <p><strong>Task Type: </strong><?php echo $row['task_type']; ?></p>
              <p><strong>Description: </strong><textarea rows="2" readonly><?php echo nl2br($row['ticket']); ?></textarea></p>
              <p><strong>Internal Notes: </strong><textarea rows="4" readonly><?php echo nl2br($row['internal_notes']); ?></textarea></p>
              <?php if($row['admin_remark']!=''):?>
                  <br></br>

              <p><strong>Admin Remarks: </strong><?php echo $row['admin_remark'];?></p>
              <p class="small-text">Posted on <?php echo $row['admin_remark_date'];?></p>
              <?php endif; ?>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
<?php }
} else { ?>
    <h3 align="center" style="color:red;">No Record found</h3>
<?php } ?>

    </div>
  </div>
</div>
</div>

<!-- JS and Bootstrap scripts -->
<script src="assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/core.js" type="text/javascript"></script>
<script src="assets/js/chat.js" type="text/javascript"></script>
</body>
</html>

<style>
/* Style for the tickets cards */
.card-inverse {
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* Style for the Total Tickets, Open Tickets, and Closed Tickets cards */

/* Total Tickets - Blue */
.card-info {
    background-color: #007bff !important;  /* Blue color for total tickets */
    border-color: #007bff !important;
}

/* Open Tickets - Red */
.card-primary {
    background-color: #dc3545 !important; /* Red color for open tickets */
    border-color: #dc3545 !important;
}

/* Closed Tickets - Green */
.card-success {
    background-color: #28a745 !important; /* Green color for closed tickets */
    border-color: #28a745 !important;
}

/* Style the card header */
.card-header {
    padding: 8px;
    font-size: 14px;  /* Smaller font size */
    color: white;     /* White text color */
}

/* Style the card body */
.card-body {
    padding: 5px;
    font-size: 16px;  /* Adjusted font size for better readability */
}

/* Icon style */
.card-body i {
    color: #fff;
    font-size: 30px; /* Adjust the icon size */
}

/* Styling for the total ticket number */
.card-body span {
    font-size: 22px;  /* Font size for the ticket number */
    font-weight: bold;
    color: white;     /* White color for the ticket number */
}

/* Optional: Style the card title to make it smaller */
.card-title {
    font-size: 14px;
    font-weight: normal;
    margin-bottom: 0;
    color: white;
}

.modal-backdrop {
    background-color: rgba(0, 0, 0, 0.2) !important; /* Lighter, less opaque backdrop */
    backdrop-filter: white;
}

/* Modal content with white background and clean look */
.modal-content {
    background-color: #fff;
    color: #333;  /* Dark text for readability */
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);  /* Soft shadow */
    width: 80%;  /* Adjust the width */
    max-width: 1000px; /* Max width */
    margin: auto;
}

/* Modal header with a bold title */
.modal-header {
    border-bottom: 2px solid #f1f1f1;
    padding-bottom: 2px;
    margin-bottom: 2px;
}

.modal-header h4 {
    font-size: 24px;
    font-weight: bold;
    margin: 5;
}

/* Close button style */
.modal-header .close {
    color: #333;
    font-size: 30px;
    opacity: 1;
}

.modal-header .close:hover,
.modal-header .close:focus {
    color: #000;
    text-decoration: none;
    opacity: 0.8;
}

/* Modal body with proper spacing */
.modal-body {
    padding: 20px;
    font-size: 16px;
    line-height: 1.5;
}

/* Modern button style */
.btn-blue {
    background-color: #007bff !important;
    color: white !important;
    border-radius: 5px;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s;
}

.btn-blue:hover {
    background-color: #0056b3 !important;
}

/* Label styles */
.label-warning {
    background-color: red !important;
    color: white;
    text-transform: uppercase;
    font-weight: bold;
}

.label-important {
    background-color: green !important;
    color: white;
    text-transform: uppercase;
    font-weight: bold;
}
.modal-title {
  color: blue;
  font-size: 24px; /* Adjust the size as needed */
}



/* Responsive adjustments for smaller screens */
@media (max-width: 768px) {
    .modal-content {
        width: 90%;
    }
}

</style>



<a id="main-menu-toggle" href="#main-menu" class="">
          <div class="iconset top-menu-toggle-white"></div>
          </a>