<?php
session_start();
error_reporting(0);
include("checklogin.php");
check_login();
include("dbconnection.php");

if(isset($_POST['change'])) {
    $oldpas = $_POST['oldpass'];
    $userid = $_SESSION['id'];
    $newpassword = $_POST['newpass'];

    // Check if the old password is correct
    $sql = mysqli_query($con, "SELECT password FROM user WHERE password='$oldpas' AND id='$userid'");
    $num = mysqli_num_rows($sql);  // Check number of rows returned by the query

    if ($num > 0) {
        // If old password matches, update the new password
        $sql_update = mysqli_query($con, "UPDATE user SET password='$newpassword' WHERE id='$userid'");
        $_SESSION['msg1'] = "Password Changed Successfully !!";
    } else {
        // If old password doesn't match
        $_SESSION['msg1'] = "Old Password does not match !!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>CRM | Change Password</title>

    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Include FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">

    <!-- Custom styles (optional) -->
    <style>
        .panel {
            border: 1px solid #ddd;
            border-radius: 20px;
            padding: 15px;
        }
        .panel-body {
            padding: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }

        /* Center the form both vertically and horizontally */
        .full-height {
            min-height: 100vh;  /* Full viewport height */
            display: flex;
            justify-content: center;  /* Horizontally center */
            align-items: center;  /* Vertically center */
        }
    </style>
</head>
<body class="full-height">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="panel">
                    <h3 class="text-center">Change Password</h3>
                    <form name="form1" method="post" onsubmit="return valid();">
                        <!-- Display session message -->
                        <?php if ($_SESSION['msg1']) { ?>
                            <div class="alert alert-info">
                                <?php echo $_SESSION['msg1']; $_SESSION['msg1'] = ""; ?>
                            </div>
                        <?php } ?>

                        <div class="form-group">
                            <label for="oldpass">Current Password</label>
                            <input type="password" name="oldpass" id="oldpass" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="newpass">New Password</label>
                            <input type="password" name="newpass" id="newpass" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="confirmpassword">Confirm New Password</label>
                            <input type="password" name="confirmpassword" id="confirmpassword" class="form-control" required>
                        </div>

                        <button type="reset" class="btn btn-secondary">Clear Form</button>
                        <button type="submit" name="change" class="btn btn-primary pull-right">Change</button>
                        <!-- Back to Home button -->
                        <button type="button" class="btn btn-warning" onclick="window.location.href='dashboard.php';">Back To Home</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Include Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function valid() {
            if (document.form1.oldpass.value == "") {
                alert("Old Password Field Empty!!");
                document.form1.oldpass.focus();
                return false;
            }
            if (document.form1.newpass.value == "") {
                alert("New Password Field Empty!!");
                document.form1.newpass.focus();
                return false;
            }
            if (document.form1.confirmpassword.value == "") {
                alert("Re-Type Password Field Empty!!");
                document.form1.confirmpassword.focus();
                return false;
            }
            if (document.form1.newpass.value.length < 6) {
                alert("Password must be at least 6 characters!!");
                document.form1.newpass.focus();
                return false;
            }
            if (document.form1.confirmpassword.value.length < 6) {
                alert("Re-Type Password must be at least 6 characters!!");
                document.form1.confirmpassword.focus();
                return false;
            }
            if (document.form1.newpass.value != document.form1.confirmpassword.value) {
                alert("Password and Re-Type Password do not match!!");
                document.form1.newpass.focus();
                return false;
            }
            return true;
        }
    </script>
</body>
</html>
