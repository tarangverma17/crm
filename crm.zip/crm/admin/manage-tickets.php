<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();
// Query to get the total number of tickets
$totalTicketsQuery = mysqli_query($con, "SELECT COUNT(*) as total_tickets FROM ticket");
$totalTicketsRow = mysqli_fetch_array($totalTicketsQuery);
$totalTickets = $totalTicketsRow['total_tickets'];

// Query to get the number of open tickets
$openTicketsQuery = mysqli_query($con, "SELECT COUNT(*) as open_tickets FROM ticket WHERE status = 'open'");
$openTicketsRow = mysqli_fetch_array($openTicketsQuery);
$openTickets = $openTicketsRow['open_tickets'];

// Query to get the number of closed tickets
$closedTicketsQuery = mysqli_query($con, "SELECT COUNT(*) as closed_tickets FROM ticket WHERE status = 'closed'");
$closedTicketsRow = mysqli_fetch_array($closedTicketsQuery);
$closedTickets = $closedTicketsRow['closed_tickets'];


if (isset($_POST['update'])) {
    $adminremark = mysqli_real_escape_string($con, $_POST['aremark']);
    $fid = $_POST['frm_id'];


    echo "Admin Remark: " . $adminremark . "<br>";
    echo "Ticket ID: " . $fid . "<br>";


    if (is_numeric($fid)) {
        $updateQuery = "UPDATE ticket SET admin_remark = '$adminremark', status = 'closed' WHERE id = '$fid'";

        if (mysqli_query($con, $updateQuery)) {
            echo '<script>alert("Ticket has been updated.")</script>';
        } else {
            echo '<script>alert("Error: ' . mysqli_error($con) . '")</script>';
        }
    } else {
        echo '<script>alert("Invalid Ticket ID.")</script>';
    }
}
?>



<!DOCTYPE html>
<html>
<head>
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta charset="utf-8" />
<title>User | Ticket Support</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta content="" name="description" />
<meta content="" name="author" />
<link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
<link href="../assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/boostrapv3/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/plugins/jquery-scrollbar/jquery.scrollbar.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/responsive.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>
</head>

<body class="">
<?php include("header.php");?>
<div class="page-container row">

      <?php include("leftbar.php");?>

      <div class="clearfix"></div>
    </div>
  </div>


  <div class="page-content">
    <div id="portlet-config" class="modal hide">
      <div class="modal-header">
        <button data-dismiss="modal" class="close" type="button"></button>
        <h3>Widget Settings</h3>
      </div>
      <div class="modal-body"> Widget settings form goes here </div>
    </div>
    <div class="clearfix"></div>
    <div class="content">
      <ul class="breadcrumb">
        <li>
          <p>Home</p>
        </li>
        <li><a href="" class="active">View Ticket</a></li>
      </ul>
<div class="row">
  <div class="col-md-4">
    <div class="tiles red m-b-10">
      <div class="tiles-body">
         <div class="widget-stats">
        <h4 class="card-title text-center" style="font-size: 20px; font-weight: bold; color: #fff;">TOTAL TICKETS</h4>
            <span style="font-size: 20px; class="item-count animate-number semi-bold data-value="<?php echo $totalTickets;?>" data-animation-duration="700"><?php echo $totalTickets;?></span>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="tiles green m-b-10">
      <div class="tiles-body">
        <div class="widget-stats">
        <h4 class="card-title text-center" style="font-size: 20px; font-weight: bold; color: #fff;">OPEN TICKETS</h4>
            <span style="font-size: 20px; class="item-count animate-number semi-bold data-value="<?php echo $openTickets;?>" data-animation-duration="700"><?php echo $openTickets;?></span>
        </div>
      </div>
    </div>
  </div>

  <div class="col-md-4">
    <div class="tiles yellow m-b-10">
      <div class="tiles-body">
        <div class="widget-stats">
        <h4 class="card-title text-center" style="font-size: 20px; font-weight: bold; color: #fff;">CLOSED TICKETS</h4>
            <span style="font-size: 20px; class="item-count animate-number semi-bold data-value="<?php echo $closedTickets;?>" data-animation-duration="700"><?php echo $closedTickets;?></span>
        </div>
      </div>
    </div>
  </div>
</div>

     <!--  <div class="page-title"> <i class="icon-custom-left"></i>
        <h3>Ticket Support</h3>
      </div> -->

      <div class="clearfix"></div>

      <h4> <span class="semi-bold">Manage Tickets</span></h4>

      <br>
     <?php $rt=mysqli_query($con,"select * from ticket order by id desc");
                          while($row=mysqli_fetch_array($rt))
                          {
                          ?>


      <div class="row">
        <div class="col-md-12">
          <div class="grid simple no-border">
            <div class="grid-title no-border descriptive clickable">
              <h4 class="semi-bold"><?php echo $row['enduser_contact_name'];?></h4>
              <p ><span class="text-success bold">Ticket #<?php echo $_SESSION['sid']=$row['ticket_id'];?></span> - Created on <?php echo $row['posting_date'];?>
              <br></br>
<strong style="color: orange;">Status - </strong><span class="label <?php echo ($row['status'] == 'closed') ? 'label-important' : 'label-warning'; ?>">
    <?php echo $row['status']; ?>
</span><div class="actions">
  <button class="btn btn-blue" type="button" data-toggle="modal" data-target="#viewTicketModal<?php echo $row['ticket_id'];?>">
  <i class="fa fa-eye"></i> View
</button>
<button class="btn btn-warning view-button" type="button" onclick="window.location.href='admin_view_ticket.php?ticket_id=<?php echo $row['ticket_id']; ?>'">
    <i class="fa fa-pencil"></i>Edit
</button>

<button class="btn btn-danger delete-button" type="button" onclick="window.location.href='admin_delete_ticket.php?ticket_id=<?php echo $row['ticket_id']; ?>'">
   <i class="fa fa-ticket"></i></i>Delete
</button>


</div>
            </div>
            <div class="grid-body  no-border" style="display:none">
              <div class="post">
                <div class="clearfix"></div>
              </div>
              <br>
              <div class="form-actions">
                <div class="post col-md-12">
                  <div class="user-profile-pic-wrapper">
                    <div class="user-profile-pic-normal"> <img width="35" height="35" data-src-retina="../assets/img/admin.png" data-src="../assets/img/admin.png" src="../assets/img/admin.png" alt=""> </div>

                  </div>
                    <br></br>
                  <div class="info-wrapper">
 <form name="adminr"  method="post" enctype="multipart/form-data">

<p><strong>Admin Remark:</strong>  <br> <textarea name="aremark" cols="50" rows="4" required="true"><?php echo $row['admin_remark'];?></textarea>
                      <hr>

<p class="small-text">
  <!-- Converted to a danger button using Bootstrap classes -->
  <button name="update" type="submit" class="btn btn-danger" id="Update" style="width: 45%;">Close Ticket</button>
  <input name="frm_id" type="hidden" id="frm_id" value="<?php echo $row['id'];?>" />
</p>

      <!-- Modal Structure to view ticket details -->
      <div class="modal fade" id="viewTicketModal<?php echo $row['ticket_id'];?>" tabindex="-1" role="dialog" aria-labelledby="viewTicketModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
              <h5 class="modal-title" id="viewTicketModalLabel">Ticket Details</h5>
            </div>
            <div class="modal-body">
              <!-- Ticket Details -->
<div style="text-align: left;">
  <p><strong style="color: red;">Ticket id: </strong><span style="color: red;"><?php echo $row['ticket_id']; ?></span></p>
</div>
<strong style="color: green;">Status - </strong><span class="label <?php echo ($row['status'] == 'closed') ? 'label-important' : 'label-warning'; ?>" style="font-weight: bold;">
  <?php echo $row['status']; ?>
</span>
<br></br>
              <p><strong>Contact Name: </strong><?php echo $row['enduser_contact_name']; ?></p>
              <p><strong>Email: </strong><?php echo $row['enduser_contact_email']; ?></p>
              <p><strong>Phone: </strong><?php echo $row['enduser_contact_phone']; ?></p>
              <p><strong>Subject: </strong><?php echo $row['subject']; ?></p>
              <p><strong>Priority: </strong><?php echo $row['priority']; ?></p>
              <p><strong>Task Type: </strong><?php echo $row['task_type']; ?></p>
              <p><strong>Description: </strong><textarea rows="2" readonly><?php echo nl2br($row['ticket']); ?></textarea></p>
              <p><strong>Internal Notes: </strong><textarea rows="4" readonly><?php echo nl2br($row['internal_notes']); ?></textarea></p>
              <p><strong>External Notes: </strong><textarea rows="4" readonly><?php echo nl2br($row['external_notes']); ?></textarea></p>
              <?php if($row['admin_remark']!=''):?>
              <p><strong>Admin Remarks: </strong><?php echo $row['admin_remark'];?></p>
              <p class="small-text">Posted on <?php echo $row['admin_remark_date'];?></p>
              <?php endif; ?>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
                    </form>
                    </div>
                    <div class="clearfix"></div>
                  </div>
                  <div class="clearfix"></div>
                </div>
              </div>
            </div>
               <?php } ?>
          </div>
        </div>


          </div>
        </div>
      </div>


          </div>
        </div>
      </div>

          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<!-- END CONTAINER -->
<!-- BEGIN CORE JS FRAMEWORK-->
<script src="../assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="../assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/plugins/breakpoints.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-unveil/jquery.unveil.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-block-ui/jqueryblockui.js" type="text/javascript"></script>
<!-- END CORE JS FRAMEWORK -->
<!-- BEGIN PAGE LEVEL JS -->
<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-scrollbar/jquery.scrollbar.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-numberAnimate/jquery.animateNumbers.js" type="text/javascript"></script>
<script src="../assets/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js" type="text/javascript"></script>
<script src="../assets/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<!-- END PAGE LEVEL PLUGINS -->
<script src="../assets/js/support_ticket.js" type="text/javascript"></script>
<!-- BEGIN CORE TEMPLATE JS -->
<script src="../assets/js/core.js" type="text/javascript"></script>
<script src="../assets/js/chat.js" type="text/javascript"></script>
<script src="../assets/js/demo.js" type="text/javascript"></script>
<!-- END CORE TEMPLATE JS -->
</body>
</html>


<style>
  /* Adjust font sizes for .item-title */
.item-title {
  font-size: 20px; /* Small size */
}

.item-title.large {
  font-size: 30px; /* Medium size */
}

.item-title.xlarge {
  font-size: 40px; /* Large size */
}

.item-title.xxlarge {
  font-size: 50px; /* Extra Large size */
}


  /* Remove line/underline after the text and number */

  /* General Tile Styling */
  /* Make the icon bigger */
/* Make the icon bigger and change color to black */
.fa-ticket {
  font-size: 30px; /* Adjust this value as needed */
  margin-right: 10px; /* Space between the icon and text */
  color: ghostwhite; /* Set the icon color to black */
}


/* General Styling for Text */
.tiles-body {
  text-align: center;
}

.tiles-title {
  font-size: 50px; /* Title text size */
  font-weight: bold;
  margin-bottom: 5px;
  color: #000; /* Ensure text is black */
}

.widget-stats {
  font-size: 1px; /* Adjust this value to increase the size of the inner text */
  font-weight: bold;
}

.item-title {
  font-size: 40px; /* Size for the title inside the tile (like TOTAL TICKETS, OPEN TICKETS, etc.) */
  margin-bottom: 40px;
}

.item-count {
  font-size: 32px; /* Increase the size for the count (numbers) */
  font-weight: bold;
}


/* Color Customization */


.tiles.green {
  background-color: #dc3545; /* Green for Closed Tickets */
}

.tiles.yellow {
  background-color: #28a745; /* Blue for Overall Tickets */
}

.tiles.red {
  background-color: #007bff; /* Red for Open Tickets */
}


  .modal-backdrop {
    background-color: rgba(0, 0, 0, 0.2) !important;
    backdrop-filter: white;
}
.modal-content {
    background-color: #fff;
    color: #333;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
    width: 90%;
    max-width: 1000px;
    margin: auto;
}
.modal-body {
    padding: 20px;
    font-size: 16px;
    line-height: 1.5;
    max-height: 520px;
    overflow-y: auto;
}
.modal-header {
    border-bottom: 2px solid #f1f1f1;
    padding-bottom: 10px;
    margin-bottom: 10px;
}
.modal-header h4 {
    font-size: 24px;
    font-weight: bold;
    margin: 5;
}
.modal-header .close {
    color: #333;
    font-size: 30px;
    opacity: 1;
}
.modal-header .close:hover,
.modal-header .close:focus {
    color: #000;
    text-decoration: none;
    opacity: 0.8;
}
.btn-blue {
    background-color: #007bff !important;
    color: white !important;
    border-radius: 5px;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    cursor: pointer;
    transition: background-color 0.3s;
}
.label-warning {
    background-color: red !important;
    color: white;
    text-transform: uppercase;
    font-weight: bold;
}
.label-important {
    background-color: green !important;
    color: white;
    text-transform: uppercase;
    font-weight: bold;
}
.btn-blue {
    background-color: #007bff !important;
    border-color: #007bff !important;
    color: white !important;
}
.modal-title {
  color: blue;
  font-size: 24px;
}
@media (max-width: 768px) {
    .modal-content {
        width: 90%;
    }
}
</style>