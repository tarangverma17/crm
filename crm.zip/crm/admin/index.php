<?php
session_start();
error_reporting(0);
include("dbconnection.php");

if(isset($_POST['login']))
{
    $ret = mysqli_query($con, "SELECT * FROM admin WHERE email='".$_POST['email']."' and password='".$_POST['password']."'");
    $num = mysqli_fetch_array($ret);
    if($num > 0)
    {
        $extra = "home.php";
        $_SESSION['alogin'] = $_POST['email'];
        $_SESSION['id'] = $num['id'];
        echo "<script>window.location.href='".$extra."'</script>";
        exit();
    }
    else
    {
        $_SESSION['action1'] = "*Invalid email or password";
        $extra = "index.php";
        echo "<script>window.location.href='".$extra."'</script>";
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM | Admin Login</title>
    <link href="assets/plugins/boostrapv3/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/style.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css"/>
    <link href="assets/css/custom-icon-set.css" rel="stylesheet" type="text/css"/>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .login-container h2 {
            font-size: 24px;
            margin-bottom: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-label {
            font-size: 16px;
            font-weight: bold;
            color: #333;
        }

        .form-control {
            width: 100%;
            padding: 12px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 16px;
            color: #333;
        }

        .form-control:focus {
            outline: none;
            border-color: #5c9dff;
        }

        .btn-login {
            background-color: #5c9dff;
            color: #fff;
            padding: 12px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }

        .btn-login:hover {
            background-color: #4a8fdb;
        }

        .error-message {
            color: #F00;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .forgot-password {
            font-size: 14px;
            color: #888;
            text-decoration: none;
        }

        .forgot-password:hover {
            color: #5c9dff;
        }
    </style>
</head>
<body class="error-body no-top">
<div class="container">
    <div class="row login-container column-seperation">
        <div class="col-md-5 col-md-offset-1">
            <h2>Sign in to CRM Admin</h2>
        </div>
        <div class="col-md-5">
            <form id="login-form" class="login-form" action="" method="post">
                <div class="error-message">
                    <?php echo $_SESSION['action1']; $_SESSION['action1'] = ""; ?>
                </div>
                <div class="row">
                    <div class="form-group col-md-12">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" id="txtusername" class="form-control" required>
                    </div>
                </div>

                <div class="row">
                    <div class="form-group col-md-12">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" id="txtpassword" class="form-control" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <button class="btn btn-primary btn-cons pull-right btn-login" name="login" type="submit">Login</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/plugins/pace/pace.min.js" type="text/javascript"></script>
<script src="assets/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
<script src="assets/js/login.js" type="text/javascript"></script>

</body>
</html>

