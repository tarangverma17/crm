<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "crm";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check for connection errors
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>

<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'errors.log');

// Include database connection
include("dbconnection.php");

// Ensure $conn is available
if (!isset($conn)) {
    die("Database connection not found. Please check dbconnection.php");
}

// Validate ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['status'] = "Invalid request. No valid ID provided.";
    $_SESSION['status_code'] = "danger";
    header('Location: manage-users.php');
    exit();
}

$id = intval($_GET['id']); // Sanitize ID input

// Prepare the DELETE query
$stmt = $conn->prepare("DELETE FROM `user` WHERE id = ?");
if ($stmt === false) {
    $_SESSION['status'] = "Database prepare error: " . $conn->error;
    $_SESSION['status_code'] = "danger";
    header('Location: manage-users.php');
    exit();
}

$stmt->bind_param("i", $id);

// Execute and check for success
if ($stmt->execute()) {
    $_SESSION['status'] = "You have successfully deleted the user.";
    $_SESSION['status_code'] = "success";
} else {
    $_SESSION['status'] = "Failed to delete the user. Error: " . $stmt->error;
    $_SESSION['status_code'] = "danger";
}

$stmt->close();
$conn->close();

// Redirect to manage users page
header('Location: manage-users.php');
exit();
?>
