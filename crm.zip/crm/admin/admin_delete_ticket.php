<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Include your database connection file
include('dbconnection.php');

// Check if ticket_id is provided and confirmation is "yes"
if (isset($_GET['ticket_id']) && isset($_GET['confirm_delete']) && $_GET['confirm_delete'] == 'yes') {
    // Get the ticket ID from the URL
    $ticket_id = $_GET['ticket_id'];

    // Prepare the DELETE query
    $sql = "DELETE FROM ticket WHERE ticket_id = ?";

    // Prepare and bind the statement
    if ($stmt = $con->prepare($sql)) {
        // Bind the ticket_id to the statement
        $stmt->bind_param("i", $ticket_id);

        // Execute the query to delete the ticket
        if ($stmt->execute()) {
            //Redirect to the admin page or ticket list after deletion
            header('Location: manage-tickets.php'); // Adjust the redirect as necessary
            exit();
        } else {
            // Error in deletion
            echo "Error deleting ticket: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $con->error;
    }
} elseif (isset($_GET['ticket_id'])) {
    // If ticket_id is provided but no confirmation has been made, show the confirmation prompt
    echo "<script type='text/javascript'>
        var result = confirm('Are you sure you want to delete this ticket?');
        if (result) {
            // Redirect to the same page with confirmation to delete the ticket (with `confirm_delete=yes` in the URL)
            window.location.href = '?ticket_id=" . $_GET['ticket_id'] . "&confirm_delete=yes';
        } else {
            // If canceled, redirect back to the manage-tickets page
            window.location.href = 'manage-tickets.php';
        }
    </script>";
} else {
    echo "Ticket ID is not provided!";
}

// Close the database connection
$con->close();
?>
