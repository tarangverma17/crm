 <!-- BEGIN SIDEBAR -->
  <div class="page-sidebar" id="main-menu">
    <!-- BEGIN MINI-PROFILE -->
    <div class="page-sidebar-wrapper scrollbar-dynamic" id="main-menu-wrapper">
      <div class="user-info-wrapper">
        <div class="profile-wrapper" style="border:solid #fff 1px;"> <img src="../assets/img/admin.png"  alt="" data-src="../assets/img/admin.png" data-src-retina="../assets/img/admin.png" width="69" height="69"  /> </div>
        <div class="user-info">
          <div class="greeting">Welcome</div>
          <div class="username">Admin</div>

        </div>
      </div>
      <!-- END MINI-PROFILE -->
      <!-- BEGIN SIDEBAR MENU -->
      <p class="menu-title">BROWSE <span class="pull-right"><a href="javascript:;"><i class="fa fa-refresh"></i></a></span></p>

    <ul>	
      <li class="start"> <a href="home.php"> <i class="icon-custom-home"></i> <span class="title">Dashboard</span>  </a> 
		    </li>
    
          <li><a href="change-password.php"><span class="fa fa-edit"></span> Change Password</a></li>
                            <li><a href="manage-users.php"><span class="fa fa-users"></span> Users</a></li>
                          <li><a href="manage-tickets.php"><span class="fa fa-ticket"></span> Manage Ticket</a></li>
                              <li ><a href="manage-quotes.php"> <span class="fa fa-tasks"></span> Manage Quotes</a></li>

                           <a href="user-access-log.php">
        <span class="fa fa-spinner" style="font-size:24px;color:green"></span>
        User Access Log
    </a>


                             
							    
                          
							
                           
    </ul>
  <style>
    .fa-spinner {
    animation: spin 0.5s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>