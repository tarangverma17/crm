<?php
session_start();
include("dbconnection.php");
include("checklogin.php");
check_login();

// Update ticket when 'update' button is clicked
if (isset($_POST['update'])) {
    // Sanitize and validate the input data
    $adminremark = mysqli_real_escape_string($con, $_POST['aremark']);
    $fid = intval($_POST['frm_id']); // Ensure $fid is an integer

    // Prepare the update query with a prepared statement
    $updateQuery = $con->prepare("UPDATE ticket SET admin_remark = ?, status = 'closed' WHERE id = ?");
    $updateQuery->bind_param("si", $adminremark, $fid);

    if ($updateQuery->execute()) {
        echo '<script>alert("Ticket has been updated.")</script>';
    } else {
        echo '<script>alert("Error updating ticket.")</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <meta charset="utf-8" />
    <title>User | Ticket Support</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="" name="description" />
    <meta content="" name="author" />
    <link href="../assets/plugins/pace/pace-theme-flash.css" rel="stylesheet" type="text/css" media="screen"/>
    <link href="../assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/plugins/font-awesome/css/font-awesome.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/animate.min.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/style.css" rel="stylesheet" type="text/css"/>
    <link href="../assets/css/responsive.css" rel="stylesheet" type="text/css"/>
</head>
<body class="">
<?php include("header.php"); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- Form Container -->
            <div class="card">
                <div class="card-header bg-primary text-white text-center">
                    <h5>Admin Remark</h5>
                </div>
                <div class="card-body">
                    <form name="adminr" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="aremark"><strong>Admin Remark</strong></label>
                            <textarea name="aremark" id="aremark" class="form-control" rows="4" required="true"><?php echo htmlspecialchars($row['admin_remark']); ?></textarea>
                        </div>

                        <!-- Hidden input for ticket ID -->
                        <input name="frm_id" type="hidden" id="frm_id" value="<?php echo htmlspecialchars($row['id']); ?>" />

                        <div class="form-group text-center">
                            <button name="update" type="submit" class="btn btn-danger" id="Update" style="width: 45%;">Close Ticket</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Core JS Framework -->
<script src="../assets/plugins/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="../assets/plugins/jquery-ui/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
<script src="../assets/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="../assets/plugins/pace/pace.min.js" type="text/javascript"></script>
</body>
</html>
